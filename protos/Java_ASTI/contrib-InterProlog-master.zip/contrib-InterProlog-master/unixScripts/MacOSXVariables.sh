# Mac OS locations are typically different from Linux
# You might want to edit unixVariable.sh variables starting from these:
JAVA_BIN=/System/Library/Frameworks/JavaVM.framework/Versions/1.4.2/Home/bin
XSB_BIN_DIRECTORY=/MY_XSB_DIR/config/powerpc-apple-darwin7.9.0/bin
SWI_BIN_DIRECTORY=/usr/local/lib/swipl-5.4.7/bin/powerpc-darwin6.6
YAP_BIN_DIRECTORY=/usr/local/bin
