:- public p/0.
p :- a.
a.
%%%%%%%%%%%%%%%%
p :- a.
a.
