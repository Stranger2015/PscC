
#define FLORA_META_PREFIX         "_$_$_flora'mod"
#define FLORA_META_PREFIX_LEN     14
#define ERGO_META_PREFIX          "_$_$_ergo'mod"
#define ERGO_META_PREFIX_LEN      13
