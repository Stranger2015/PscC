#!/bin/sh

. ../../../flora2/java/flora_settings.sh

CP=../../../flora2/java/interprolog.jar:bin
java -cp $CP iptest.InterPrologTest $PROLOGDIR/xsb $FLORADIR
