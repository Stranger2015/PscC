import net.sf.flora2.API.PrologFlora;
//import org.junit.Assert;
//import org.junit.Test;

import java.io.File;

/**
 * Created by elenius on 12/16/16.
 */
public class LoadTest {

    // CHANGE prologDir and floraDir for your system!!!
    private static final String prologDir = "/home/kifer/XSB/XSB-git/XSB/config/x86_64-unknown-linux-gnu/bin";
    private static final String floraDir = "/home/kifer/FLORA/flora-git/flora2";

    public static void main(String[] args) {
        System.setProperty("PROLOGDIR",prologDir);
        System.setProperty("FLORADIR",floraDir);
        PrologFlora pf = new PrologFlora();
        File testfile = new File("foo/test2.flr");
        String path = testfile.getAbsolutePath();
        System.out.println("Loading file: " + path);
        //Assert.assertTrue(testfile.exists());
        boolean success = pf.loadFile(path,"main");
        System.out.println("Success = "+success);
        //Assert.assertTrue(success);
	System.exit(0);
    }
}
