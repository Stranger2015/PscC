
BASE=../../..
#BASE=$HOME/tmp/Flora-2

java -classpath .:$BASE/flora2/java/interprolog.jar:$BASE/flora2/java/flora2java.jar LoadTest
