
rm -f *.P *.xwam *.fld *.fls *.flm *.fdb *.flt
