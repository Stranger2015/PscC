

rm -f *.P *.xwam *.fld *.fls *.flm *.fdb *.flt
cd ..
rm -f *.P *.xwam *.fld *.fls *.flm *.fdb *.flt
